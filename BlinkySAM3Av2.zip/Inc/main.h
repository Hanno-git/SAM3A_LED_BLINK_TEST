/*
 * main.h
 *
 * Created: 2022/03/04 08:42:02
 *  Author: hanno
 */ 


#ifndef MAIN_H_
#define MAIN_H_

#include <sam3a4c.h>
#include <component/pio.h>



#endif /* MAIN_H_ */